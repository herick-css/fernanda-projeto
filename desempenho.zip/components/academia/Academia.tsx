"use client";

import dynamic from "next/dynamic";
import { useEffect, useRef, useState } from "react";
import { ESTACOES } from "./dados";

// A cena 3D só carrega no navegador (three não roda no servidor)
const AcademiaCena = dynamic(() => import("./AcademiaCena"), {
  ssr: false,
});

const Reserva = () => (
  <div className="h-[min(78vh,720px)] min-h-[460px] w-full" aria-hidden="true" />
);

export default function Academia() {
  const ref = useRef<HTMLDivElement>(null);
  const [perto, setPerto] = useState(false);

  // Só baixa o three.js quando a seção está perto de aparecer,
  // para não competir com o vídeo e o resto da página no carregamento.
  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const obs = new IntersectionObserver(
      ([entrada]) => {
        if (entrada.isIntersecting) {
          setPerto(true);
          obs.disconnect();
        }
      },
      { rootMargin: "600px" },
    );
    obs.observe(el);

    return () => obs.disconnect();
  }, []);

  return (
    <div ref={ref}>
      {perto ? <AcademiaCena /> : <Reserva />}

      <p className="mt-4 text-center text-sm text-slate-500">
        Explore a academia: passe o mouse nos pontos numerados e clique (ou toque) para ler.
      </p>

      {/* Mesmo conteúdo em texto, para leitores de tela e buscadores */}
      <ul className="sr-only">
        {ESTACOES.map((e) => (
          <li key={e.id}>
            <strong>{e.titulo}</strong>: {e.texto}
          </li>
        ))}
      </ul>
    </div>
  );
}
